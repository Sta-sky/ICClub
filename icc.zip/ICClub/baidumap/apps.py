from django.apps import AppConfig


class BaiduaddressConfig(AppConfig):
    name = 'baidumap'
