// 发送数据
$(function () {
    var $collect = $('#sc');
    var $r1 = $('#r1');
    var $read=$('#read');
    var $send =$('#send')

    $


})

