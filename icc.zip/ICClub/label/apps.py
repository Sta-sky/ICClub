from django.apps import AppConfig


class LabelConfig(AppConfig):
    name = 'label'
