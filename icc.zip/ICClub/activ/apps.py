from django.apps import AppConfig


class ActivConfig(AppConfig):
    name = 'activ'
