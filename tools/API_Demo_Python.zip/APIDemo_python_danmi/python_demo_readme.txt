
运行环境:python版本3.6.4及以上

第一步：确保 python环境就绪，以windows为例，在DOS命令行模式下输入python命令可以进入python环境
第二步:展开压缩包，使用文本编辑器打开python_demo.py文件，替换以下参数

accountSid="cdc1aabbf2d445108cc13271eexxxxxx";  //登陆官网开发者中心界面，可以查询到自己的accountSid,将该参数替换为自己的accountSid
auth_token="5ecbeaa30b6c477cb77c2bedb5xxxxxx";  //登陆官网开发者中心界面，可以查询到自己的auth_token，将该参数替换为自己的auth_token
to="186xxxxxxxx";  //替换为自己的手机号码
templateid="3284"; //登陆官网开发者中心界面,创建模版并审核通过，得到模版ID,将该参数替换为已经审核过的模版ID
param="1234";      //替换为自己想下发的动态参数


第三步:在DOS命令行模式下，进入python_demo.py文件所在目录，输入python python_demo.py  命令查看命令执行结果

